//Primero hago un evento de escucha del DOMLOADED, para que sea cada vez que cargue el documento
document.addEventListener("DOMContentLoaded", () =>{
//Voy a definir una función anónima, es decir, una función dentro de esa función. En este caso es una 
//función "flecha", por eso tiene una flechita, y la función no tiene nombre porque la definiré dentro del
//evento, se pone los paréntesis para especificar los parámetros pero en este caso, no tiene. La flecha separa
//La flecha separa los parámetros de la definición del cuerpo de la función anónima. En vez de usar eso [()=>{}]
//podría usar [function(){}]
//DEFINICIÓN DEL CUERPO DE LA FUNCIÓN
//Comenzamos llamando la función actualizarTodos(), esto es para que al cargar el documento, si ya hay datos
//previamente guardados en la localStorage, se muestren.
actualizarTodos();
//Luego, vamos a seleccionar todos los botones de la página, o todos los elementos que tenga la clase agregar.
//Esto lo hacemos con un querySelectorAll
    document.querySelectorAll(".agregar").forEach(button => {
        //el querySelectorAll nos va a devolver un array con todos los elementos que tenga la clase agregar
        //Vamos a recorrer el array con un forEach
        //Como los elementos que tienen la clase agregar son de tipo button, decimos que para cada botón
        //se ejecute una función anónima flecha
        //Hasta el momento hemos definido 2 funciones, definiremos una más con un evento de escucha para cada
        //vez que hagan click en el botón
        button.addEventListener('click',()=>{
            //Empezamos a definir variables
            const card=button.closest("card"); //Usamos el elemento button para usar el método closest, este
            //lo que hace es buscar el elemento anterior más cercano con la clase card
            const imgSrc=card.querySelector(".card-img-top").src;
            //Card se convierte en un elemento, por tanto, se ha obtenido todo lo que está dentro de él.
            // al llamar a card querySelector, busco todas las clases con el nombre que le pongamos
            //dentro del card.
            //Se usa .src y .textContent para obtener la imagen y el texto
            const nombre=card.querySelector(".card-title").textContent;
            //Debo convertir el precio a float con un parseFloat
            const precio=parseFloat(card.querySelector(".precio").textContent);

            //Creamos una variable llamada productos.Esta se va a igual a lo que devuelva el parseo de la cadena de texto productos a objeto del localStorage,si no hay nada, devuelve un vacío.Esto de paso verifica si había objetos en el array. Con el || estamos evaluando si es que se devuelve un vacío en la 
            //izquierda, se crea un objeto vacío.
            let productos=JSON.parse(localStorage.getItem("productos")) || {};

            //Verificamos si ya había un objeto con ese nombre. Para eso usamos el nombre del objeto
            //y para acceder a sus atributos se usa la sintaxis [atributo], porque si usamos la sintaxis
            //productos.nombre, tendríamos que especificarle la posición a la que queremos acceder.
            //Entonces, verificamos si ya existe el objeto con ese nombre.
            if(productos[nombre]){
                //Si ya existe, aumentamos la cantidad
                productos[nombre].cantidad++; //productos[nombre] funciona como referencia de objeto.
                //aquí es adecuado porque productos[nombre] devuelve un objeto y cantidad es una propiedad de ese objeto.
            }else{
                //Si no existe, creamos el objeto
                productos[nombre]={
                    imgSrc,
                    precio,
                    cantidad:1
                };
            }

            //guardamos en el localStorage con su función setItem
            localStorage.setItem('productos', JSON.stringify(productos));
            //primero se pone el nombre del objeto, y dentro se convierte a cadena el objeto productos
            //JSON.parse, convierte una cadena en objeto
            //JSON.stringify, convierte un objeto en una cadena
            //FINALIZAMOS CON EL ACTUALIZAR DATOS
            actualizarTodos();
        })
    })
}); 
function eliminarTodos(){
    localStorage.removeItem("productos");
    actualizarTodos();
}
function actualizarTodos(){
    //Primero obtengo la etiqueta carrito para poder insertar ahí las cards
    const carrito=document.getElementById("carrito");
    
}