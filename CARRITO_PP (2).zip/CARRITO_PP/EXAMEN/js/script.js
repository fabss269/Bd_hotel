document.addEventListener('DOMContentLoaded', () => {
    actualizarCarrito();

    document.querySelectorAll('.agregar').forEach(button => {
        button.addEventListener('click', () => {
            const card = button.closest('.card');
            const imgSrc = card.querySelector('.card-img-top').src;
            const nombre = card.querySelector('.card-title').textContent;
            const precio = parseFloat(card.querySelector('.precio').textContent);

            let productos = JSON.parse(localStorage.getItem('productos')) || {};

            if (productos[nombre]) {
                productos[nombre].cantidad++;
            } else {
                productos[nombre] = {
                    imgSrc,
                    precio,
                    cantidad: 1
                };
            }
            localStorage.setItem('productos', JSON.stringify(productos));

            actualizarCarrito();
        });
    });

    //PARA EL MODAL
    const modal = document.getElementById('modal');
    const cerrar = document.querySelector('.close');
    const aceptar = document.getElementById('aceptar');
    const pagar = document.querySelector('button[type="submit"]');
    const nombreEnviado= document.getElementById('nombre');
    const emailEnviado = document.getElementById('email');

    pagar.addEventListener('click', (event) => {
        event.preventDefault(); // Evita que se envíe el formulario por defecto
        // Aquí podrías obtener los datos del usuario y mostrarlos en el modal
        document.getElementById('nombre').textContent = nombreEnviado; // Cambia esto por el valor real
        document.getElementById('email').textContent = emailEnviado; // Cambia esto por el valor real
        document.getElementById('total-compra').textContent = '999.99'; // Cambia esto por el valor real

        modal.style.display = 'block'; // Muestra el modal
    });

    cerrar.addEventListener('click', () => {
        modal.style.display = 'none'; // Oculta el modal
    });

    aceptar.addEventListener('click', () => {
        modal.style.display = 'none'; // Oculta el modal
    });

    // Cierra el modal si se hace clic fuera del contenido del modal
    window.addEventListener('click', (event) => {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    });

});

function actualizarCarrito() {
    const carrito = document.getElementById('carrito');
    carrito.innerHTML = '';
    let total = 0;
    let productos = JSON.parse(localStorage.getItem('productos')) || {};

    for (const [nombre, producto] of Object.entries(productos)) {
        if (!producto || !producto.precio) {
            console.error(`Producto o precio no válido para "${nombre}".`);
            continue;
        }

        const productoTotal = producto.precio * producto.cantidad;
        total =total+ productoTotal;

        const productoDiv = document.createElement('div');
        productoDiv.classList.add('row', 'shadow-sm', 'bg-body-tertiary', 'border', 'pb-2', 'pt-2', 'd-flex', 'align-items-center', 'justify-content-between', 'producto');
        productoDiv.innerHTML = `
            <div class="col-2">
                <img src="${producto.imgSrc}" class="img-fluid rounded-start" alt="Imagen del Producto">
            </div>
            <div class="col-2">
                <p class="nombreProducto">${nombre}</p>
            </div>
            <div class="col-2">
                <p class="precioProducto">$${producto.precio.toFixed(2)}</p>
            </div>
            <div class="col-2">
                <p class="cantidad">${producto.cantidad}</p>
            </div>
            <div class="col-2">
                <p class="total">$${productoTotal.toFixed(2)}</p>
            </div>
            <div class="col-2">
                <button type="button" class="btn btn-danger btn-sm eliminar" data-nombre="${nombre}">X</button>
            </div>
        `;
        carrito.appendChild(productoDiv);
    }

    const totalElement = document.getElementById('total');
    if (totalElement) {
        totalElement.textContent = `$${total.toFixed(2)}`;
    }

    document.querySelectorAll('.eliminar').forEach(button => {
        button.addEventListener('click', () => {
            const nombre = button.getAttribute('data-nombre');
            let productos = JSON.parse(localStorage.getItem('productos')) || {};
            delete productos[nombre]; //operador que 
            //elimina la propiedad del objeto productos cuyo nombre es el valor de la variable nombre.
            localStorage.setItem('productos', JSON.stringify(productos));
            actualizarCarrito();
        });
    });
}

function eliminarTodo() {
    localStorage.removeItem('productos');
    actualizarCarrito();
}